"""CodeAlpha Task 2: Stock portfolio value tracker (example fixed prices)."""
import csv
from pathlib import Path

PRICES = {"AAPL": 180.0, "TSLA": 250.0, "MSFT": 420.0, "GOOGL": 175.0, "AMZN": 190.0}


def main():
    holdings = {}
    print("Stock Portfolio Tracker — example prices, NOT live market quotes")
    print("Available stocks:", ", ".join(f"{s} (${p:.2f})" for s, p in PRICES.items()))
    print("Type 'done' when finished.")
    while True:
        ticker = input("\nStock symbol: ").strip().upper()
        if ticker == "DONE":
            break
        if ticker not in PRICES:
            print("Unknown stock. Choose one from the list.")
            continue
        try:
            quantity = int(input("Quantity (whole shares): ").strip())
            if quantity <= 0:
                raise ValueError
        except ValueError:
            print("Enter a positive whole number.")
            continue
        holdings[ticker] = holdings.get(ticker, 0) + quantity
    if not holdings:
        print("No holdings entered.")
        return
    total = 0.0
    rows = []
    print("\n--- Portfolio Summary ---")
    for ticker, quantity in holdings.items():
        value = PRICES[ticker] * quantity
        total += value
        rows.append((ticker, quantity, PRICES[ticker], value))
        print(f"{ticker}: {quantity} x ${PRICES[ticker]:.2f} = ${value:.2f}")
    print(f"Total investment value: ${total:.2f}")
    if input("Save summary to CSV? (y/n): ").strip().lower() == "y":
        output = Path(__file__).with_name("portfolio_summary.csv")
        with output.open("w", newline="", encoding="utf-8") as file:
            writer = csv.writer(file)
            writer.writerow(["Stock", "Quantity", "Price_USD", "Value_USD"])
            writer.writerows(rows)
            writer.writerow(["TOTAL", "", "", f"{total:.2f}"])
        print(f"Saved to {output}")


if __name__ == "__main__":
    main()
