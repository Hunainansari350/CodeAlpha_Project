"""CodeAlpha Task 3: Extract email addresses from a text file."""
import re
from pathlib import Path

EMAIL_PATTERN = re.compile(r"\b[A-Za-z0-9._%+-]+@[A-Za-z0-9.-]+\.[A-Za-z]{2,}\b")


def main():
    base = Path(__file__).parent
    source = base / "sample_input.txt"
    destination = base / "extracted_emails.txt"
    if not source.exists():
        print(f"Input file not found: {source}")
        return
    content = source.read_text(encoding="utf-8")
    emails = sorted(set(EMAIL_PATTERN.findall(content)), key=str.lower)
    destination.write_text("\n".join(emails) + ("\n" if emails else ""), encoding="utf-8")
    print(f"Found {len(emails)} unique email(s). Saved to {destination.name}")
    for email in emails:
        print(" -", email)


if __name__ == "__main__":
    main()
