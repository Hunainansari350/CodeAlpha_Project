# CodeAlpha Python Programming Internship Projects

Four beginner friendly Python console projects following the provided CodeAlpha task descriptions. Only 2 or 3 tasks are required by the instructions; all 4 are included so you can choose.

## Requirements
- Python 3.9 or newer
- VS Code with the Python extension recommended
- No third-party packages needed

## Run in VS Code
1. Extract the ZIP file and open the `CodeAlpha_Python_Internship` folder in VS Code (File > Open Folder).
2. Open Terminal > New Terminal.
3. Run one of the commands below (use `python3` instead of `python` if needed):

| Task | Command | What it does |
|---|---|---|
| 1 — Hangman | `python hangman.py` | Guess a random word, max 6 wrong guesses |
| 2 — Stock Portfolio | `python stock_portfolio.py` | Enter symbols and quantities, optionally export CSV |
| 3 — Email Extraction | `python email_extractor.py` | Read `sample_input.txt` and write `extracted_emails.txt` |
| 4 — Chatbot | `python chatbot.py` | Chat with predefined rule-based responses |

For Task 3, replace the sample content in `sample_input.txt` with your own text before running.
For Task 2, stock prices are fixed demonstration values, not real time prices.

## Suggested GitHub repository names
Upload each selected project to a separate repository, as requested by the instructions:
- `CodeAlpha_HangmanGame` (upload `hangman.py`)
- `CodeAlpha_StockPortfolioTracker` (upload `stock_portfolio.py`)
- `CodeAlpha_TaskAutomation` (upload `email_extractor.py` and `sample_input.txt`)
- `CodeAlpha_BasicChatbot` (upload `chatbot.py`)

Include a short README in each repository explaining how to run that task. Make sure you personally run, understand, and test the scripts before submitting or recording your LinkedIn video explanation.

## Submission checklist
- [ ] Complete and test at least 2 (or 3 if instructed) tasks
- [ ] Share internship status on LinkedIn and tag @CodeAlpha
- [ ] Push code to GitHub repositories with the required names
- [ ] Share a LinkedIn video explanation with GitHub repository links
- [ ] Submit through the form shared in your WhatsApp group
