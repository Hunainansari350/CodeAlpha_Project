"""CodeAlpha Task 4: Basic rule-based chatbot."""


def get_reply(message):
    text = message.strip().lower().rstrip("!?., ")
    if text in ("hello", "hi", "hey"):
        return "Hi! How can I help you?"
    elif text in ("how are you", "how are you doing"):
        return "I'm fine, thanks! How about you?"
    elif text in ("what is your name", "your name"):
        return "I'm CodeAlpha Bot!"
    elif text in ("thank you", "thanks"):
        return "You're welcome!"
    elif text in ("bye", "goodbye", "exit", "quit"):
        return "Goodbye!"
    return "Sorry, I don't understand that yet. Try 'hello', 'how are you', or 'bye'."


def main():
    print("CodeAlpha Chatbot (type 'bye' to exit)")
    while True:
        message = input("You: ")
        if not message.strip():
            print("Bot: Please type something.")
            continue
        reply = get_reply(message)
        print("Bot:", reply)
        if message.strip().lower().rstrip("!?., ") in ("bye", "goodbye", "exit", "quit"):
            break


if __name__ == "__main__":
    main()
