"""CodeAlpha Task 1: Text-based Hangman game."""
import random

WORDS = ["python", "coding", "planet", "garden", "laptop"]
MAX_WRONG = 6


def play():
    word = random.choice(WORDS)
    guessed = set()
    wrong = 0
    print("Welcome to Hangman! Guess the word one letter at a time.")
    while wrong < MAX_WRONG:
        visible = " ".join(letter if letter in guessed else "_" for letter in word)
        print(f"\nWord: {visible}\nWrong guesses left: {MAX_WRONG - wrong}")
        if all(letter in guessed for letter in word):
            print(f"Congratulations! You guessed '{word}'!")
            return
        guess = input("Enter a letter: ").strip().lower()
        if len(guess) != 1 or not guess.isalpha() or not guess.isascii():
            print("Please enter one English letter (a-z).")
        elif guess in guessed:
            print("You already guessed that letter.")
        else:
            guessed.add(guess)
            if guess in word:
                print("Correct!")
            else:
                wrong += 1
                print("Incorrect!")
    print(f"Game over! The word was '{word}'.")


if __name__ == "__main__":
    play()
